This README file was updated on [YYYY-MM-DD] by [NAME]

GENERAL INFORMATION
Study/project title:
Description: <provide a short description of the study/project>
Authors:
Contact: <e-mail>

ORGANIZATION
- Folder structure:
Example of a top-level directory layout:
├── 01_projectcode_data           # data files
├── 02_projectcode_code           # data analysis scripts
├── 03_projectcode_docs           # documentation: protocols, DMP, etc.
└── README.txt

- File naming conventions: projectcode_description_vNN (scripts: projectcode_description)
- File formats:
